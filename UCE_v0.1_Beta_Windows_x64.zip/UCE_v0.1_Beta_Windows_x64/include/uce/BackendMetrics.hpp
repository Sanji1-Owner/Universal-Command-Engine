#pragma once

#include <chrono>
#include <unordered_map>
#include <string>
#include <atomic>
#include <cstdint>

namespace uce {

/**
 * @brief Performance metrics for a single script execution
 */
struct ExecutionMetrics {
    std::chrono::milliseconds duration{0};
    uint64_t bytesExecuted{0};
    bool timedOut{false};
    bool succeeded{false};
    std::string language;
    std::chrono::steady_clock::time_point timestamp;

    ExecutionMetrics() : timestamp(std::chrono::steady_clock::now()) {}
};

/**
 * @brief Aggregated backend performance statistics
 */
class BackendMetrics {
public:
    BackendMetrics(const std::string& backendName);

    /**
     * @brief Record a script execution
     * @param duration How long the script took to execute
     * @param bytesExecuted Number of bytes in the script
     * @param succeeded Whether execution succeeded
     * @param timedOut Whether execution timed out
     */
    void recordExecution(std::chrono::milliseconds duration, uint64_t bytesExecuted,
                        bool succeeded, bool timedOut);

    /**
     * @brief Get total execution count
     */
    uint64_t executionCount() const { return executionCount_; }

    /**
     * @brief Get successful execution count
     */
    uint64_t successCount() const { return successCount_; }

    /**
     * @brief Get failed execution count
     */
    uint64_t failureCount() const { return failureCount_; }

    /**
     * @brief Get timeout count
     */
    uint64_t timeoutCount() const { return timeoutCount_; }

    /**
     * @brief Get total bytes executed
     */
    uint64_t totalBytes() const { return totalBytes_; }

    /**
     * @brief Get average execution time in milliseconds
     */
    double averageExecutionTime() const;

    /**
     * @brief Get maximum execution time in milliseconds
     */
    std::chrono::milliseconds maxExecutionTime() const { return maxExecutionTime_; }

    /**
     * @brief Get minimum execution time in milliseconds
     */
    std::chrono::milliseconds minExecutionTime() const { return minExecutionTime_; }

    /**
     * @brief Get success rate (0.0 - 1.0)
     */
    double successRate() const;

    /**
     * @brief Reset all metrics
     */
    void reset();

    /**
     * @brief Get backend name
     */
    const std::string& name() const { return backendName_; }

    /**
     * @brief Get summary as formatted string
     */
    std::string summary() const;

    /**
     * @brief Get detailed metrics as JSON-like string
     */
    std::string details() const;

private:
    std::string backendName_;
    std::atomic<uint64_t> executionCount_{0};
    std::atomic<uint64_t> successCount_{0};
    std::atomic<uint64_t> failureCount_{0};
    std::atomic<uint64_t> timeoutCount_{0};
    std::atomic<uint64_t> totalBytes_{0};
    std::atomic<uint64_t> totalDurationMs_{0};

    std::chrono::milliseconds maxExecutionTime_{0};
    std::chrono::milliseconds minExecutionTime_{std::chrono::milliseconds(0xFFFFFFFF)};
};

/**
 * @brief Global metrics registry for all backends
 */
class MetricsRegistry {
public:
    /**
     * @brief Get or create metrics for a backend
     */
    static BackendMetrics& getMetrics(const std::string& backendName);

    /**
     * @brief Get all registered metrics
     */
    static std::unordered_map<std::string, BackendMetrics*>& allMetrics();

    /**
     * @brief Get summary of all metrics
     */
    static std::string summary();

    /**
     * @brief Reset all metrics
     */
    static void resetAll();

    /**
     * @brief Check if metrics are enabled
     */
    static bool isEnabled() { return enabled_; }

    /**
     * @brief Enable/disable metrics collection
     */
    static void setEnabled(bool enabled) { enabled_ = enabled; }

private:
    static bool enabled_;
    static std::unordered_map<std::string, BackendMetrics*> metricsMap_;
};

/**
 * @brief RAII helper for automatic metric recording
 */
class MetricsGuard {
public:
    /**
     * @brief Start timing an execution
     * @param backendName Name of the backend
     * @param bytesExecuted Size of script in bytes
     */
    MetricsGuard(const std::string& backendName, uint64_t bytesExecuted = 0);

    /**
     * @brief Record execution result and stop timing
     */
    ~MetricsGuard();

    /**
     * @brief Mark execution as succeeded
     */
    void markSuccess() { succeeded_ = true; }

    /**
     * @brief Mark execution as timed out
     */
    void markTimeout() { timedOut_ = true; }

private:
    std::string backendName_;
    uint64_t bytesExecuted_;
    std::chrono::steady_clock::time_point startTime_;
    bool succeeded_{false};
    bool timedOut_{false};
};

} // namespace uce
