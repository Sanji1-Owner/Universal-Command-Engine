#pragma once
#include <string>
#include <fstream>
#include <sstream>
#include <mutex>
#include <ctime>
#include <windows.h>

namespace uce {

/**
 * @brief Child process diagnostic logging
 * 
 * Writes to uce_child_debug.log to avoid contaminating IPC channel (stdout/stderr)
 */
class ChildDiagnostics {
public:
    static ChildDiagnostics& instance() {
        static ChildDiagnostics inst;
        return inst;
    }

    void log(const std::string& stage, const std::string& message) {
        std::lock_guard<std::mutex> lock(mutex_);
        std::ofstream file("uce_child_debug.log", std::ios::app);
        if (file.is_open()) {
            auto now = std::time(nullptr);
            auto tm = *std::localtime(&now);
            char timestamp[20];
            std::strftime(timestamp, sizeof(timestamp), "%H:%M:%S", &tm);
            
            file << "[" << timestamp << "] [" << stage << "] " << message << "\n";
            file.flush();
        }
    }

    void logPythonState(int parentPid, const std::string& language) {
        std::lock_guard<std::mutex> lock(mutex_);
        std::ofstream file("uce_child_debug.log", std::ios::app);
        if (file.is_open()) {
            file << "===== CHILD PROCESS START =====\n";
            file << "Parent PID: " << parentPid << "\n";
            file << "Language: " << language << "\n";
            file << "Time: " << std::time(nullptr) << "\n";
            file << "==============================\n";
            file.flush();
        }
    }

    void clear() {
        std::lock_guard<std::mutex> lock(mutex_);
        std::ofstream file("uce_child_debug.log", std::ios::trunc);
        if (file.is_open()) {
            file << "Child Diagnostics Log\n";
            file << "====================\n\n";
            file.flush();
        }
    }

private:
    std::mutex mutex_;
};


#define CHILD_LOG(stage, msg) uce::ChildDiagnostics::instance().log(stage, msg)
#define CHILD_LOG_PYTHON(ppid, lang) uce::ChildDiagnostics::instance().logPythonState(ppid, lang)
#define CHILD_LOG_CLEAR() uce::ChildDiagnostics::instance().clear()

} // namespace uce
