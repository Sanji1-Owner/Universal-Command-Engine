#pragma once
#include "uce/CommandResult.hpp"
#include "uce/Context.hpp"
#include <string>
#include <unordered_map>
#include <vector>
#include <functional>
#include <variant>

namespace uce {

struct ParsePosition {
    int line = 1;
    int column = 1;
};

struct CommandRequest {
    std::string source;
    std::string name;
    std::unordered_map<std::string, std::string> arguments;
    std::vector<std::string> positionalArguments;
    std::string raw;
    ParsePosition position;

    bool has(const std::string& key) const {
        return arguments.find(key) != arguments.end();
    }

    std::string get(const std::string& key, const std::string& fallback = {}) const {
        auto it = arguments.find(key);
        return it == arguments.end() ? fallback : it->second;
    }
};

enum class ArgumentType {
    String,
    Number,
    Boolean
};

struct ArgumentSchema {
    std::string name;
    ArgumentType type;
    bool required;
    std::string description;
};

struct CommandMetadata {
    std::string name;
    std::string description;
    std::vector<std::string> requiredPermissions;
    std::vector<ArgumentSchema> arguments;
};

using CommandHandler = std::function<CommandResult(const CommandRequest&, EngineContext&)>;

struct CommandDefinition {
    CommandMetadata metadata;
    CommandHandler handler;
};

} // namespace uce
