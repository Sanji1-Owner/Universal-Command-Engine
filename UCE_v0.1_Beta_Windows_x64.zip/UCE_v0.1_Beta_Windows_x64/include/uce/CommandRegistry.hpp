#pragma once
#include "uce/Command.hpp"
#include <string>
#include <unordered_map>
#include <vector>
#include <mutex>

namespace uce {

class CommandRegistry {
public:
    explicit CommandRegistry(EngineContext& context);
    void registerCommand(const CommandMetadata& metadata, CommandHandler handler);
    bool hasCommand(const std::string& name) const;
    CommandResult execute(const CommandRequest& request);
    std::vector<CommandMetadata> listCommands() const;

private:
    struct Entry {
        CommandMetadata metadata;
        CommandHandler handler;
    };

    CommandResult validateArguments(const CommandRequest& request, const CommandMetadata& metadata) const;

    EngineContext& context_;
    std::unordered_map<std::string, Entry> commands_;
    mutable std::mutex mutex_;
};

} // namespace uce
