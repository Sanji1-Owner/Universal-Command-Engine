#pragma once
#include "uce/Error.hpp"
#include <string>
#include <map>

namespace uce {

struct CommandResult {
    bool success = true;
    std::string output;
    Error error;
    std::map<std::string, std::string> data;

    static CommandResult Ok(std::string msg = {}) {
        CommandResult result;
        result.success = true;
        result.output = std::move(msg);
        return result;
    }

    static CommandResult Fail(Error error) {
        CommandResult result;
        result.success = false;
        result.error = std::move(error);
        return result;
    }

    // Legacy compatibility - convert string errors to Error
    static CommandResult Fail(std::string msg, int code = 1) {
        Error error{ErrorCode::ExecutionFailed, ErrorCategory::Runtime, std::move(msg)};
        return Fail(std::move(error));
    }

    const Error* errorInfo() const {
        return success ? nullptr : &error;
    }

    const std::string* message() const {
        return success ? &output : nullptr;
    }

    std::string toString() const {
        if (success) {
            return output.empty() ? "Success" : output;
        } else {
            return error.toString();
        }
    }
};

} // namespace uce
