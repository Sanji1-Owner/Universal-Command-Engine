#pragma once
#include <string>
#include <map>
#include <memory>
#include <unordered_map>

namespace uce {

class ILogger;
class SecurityPolicy;
class IUIBridge;

struct EngineContext {
    std::string appName;
    std::string appVersion;
    std::string workingDirectory;
    std::map<std::string, std::string> environment;
    std::unordered_map<std::string, std::string> runtimeVariables;
    ILogger* logger = nullptr;
    SecurityPolicy* security = nullptr;
    IUIBridge* uiBridge = nullptr;

    std::string getVariable(const std::string& key, const std::string& fallback = {}) const {
        auto it = runtimeVariables.find(key);
        return it == runtimeVariables.end() ? fallback : it->second;
    }

    void setVariable(std::string key, std::string value) {
        runtimeVariables[std::move(key)] = std::move(value);
    }
};

} // namespace uce
