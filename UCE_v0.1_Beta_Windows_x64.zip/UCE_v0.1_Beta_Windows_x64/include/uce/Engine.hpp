#pragma once
#include "uce/CommandRegistry.hpp"
#include "uce/CommandResult.hpp"
#include "uce/Parser.hpp"
#include "uce/Context.hpp"
#include "uce/Security.hpp"
#include "uce/ScriptBackend.hpp"
#include "uce/UIBridge.hpp"
#include "uce/Logger.hpp"
#include "uce/ProcessIsolation.hpp"
#include "uce/ExecutionSandbox.hpp"
#include <memory>
#include <string>
#include <map>
#include <vector>
#include <functional>
#include <future>

namespace uce {

class Engine {
public:
    using BeforeExecuteHook = std::function<void(const CommandRequest&, EngineContext&)>;
    using AfterExecuteHook = std::function<void(const CommandRequest&, const CommandResult&, EngineContext&)>;
    using ErrorHook = std::function<void(const CommandRequest&, const CommandResult&, EngineContext&)>;

    Engine();
    explicit Engine(EngineContext context);

    CommandResult execute(const std::string& source);
    std::future<CommandResult> executeAsync(const std::string& source);
    void registerBackend(const std::string& prefix, std::shared_ptr<IScriptBackend> backend);
    void registerCommand(const CommandMetadata& metadata, CommandHandler handler);

    // Script execution with context
    CommandResult executeScript(const std::string& language, const std::string& source);
    CommandResult executeScriptInContext(const std::string& language, ScriptExecutionContext& context);

    // SECURE MODE - Phase 6: True Isolation
    void enableSecureMode();                    // Enable mandatory process isolation
    void disableSecureMode();                   // Allow in-process execution
    bool isSecureModeEnabled() const { return secureMode_; }

    // Process isolation control
    void enableProcessIsolation();              // Enable optional process isolation
    void disableProcessIsolation();             // Use in-process execution
    bool isProcessIsolationEnabled() const { return processIsolationEnabled_; }

    // Isolation diagnostics
    ProcessIsolationManager::IsolationStats getIsolationStats() const;

    CommandRegistry& commands();
    Parser& parser();
    EngineContext& context();
    SecurityPolicy& security();
    ILogger& logger();
    IUIBridge& uiBridge();

    void addBeforeExecuteHook(BeforeExecuteHook hook);
    void addAfterExecuteHook(AfterExecuteHook hook);
    void addErrorHook(ErrorHook hook);

    // Diagnostics
    std::map<std::string, std::string> diagnostics() const;

private:
    void registerBuiltins();
    void notifyBefore(const CommandRequest& request);
    void notifyAfter(const CommandRequest& request, const CommandResult& result);
    void notifyError(const CommandRequest& request, const CommandResult& result);

    // Secure mode execution
    CommandResult executeScriptSecure(const std::string& language, ScriptExecutionContext& context);

    EngineContext context_;
    ConsoleLogger logger_;  // default logger
    SecurityPolicy security_;
    ConsoleUIBridge uiBridge_;
    CommandRegistry registry_;
    Parser parser_;
    std::map<std::string, std::shared_ptr<IScriptBackend>> backends_;
    std::vector<BeforeExecuteHook> beforeExecuteHooks_;
    std::vector<AfterExecuteHook> afterExecuteHooks_;
    std::vector<ErrorHook> errorHooks_;
    int executionDepth_ = 0; // Track recursion depth for security

    // Phase 6: Process Isolation
    bool secureMode_ = false;                          // Mandatory isolation mode
    bool processIsolationEnabled_ = false;             // Optional isolation enabled
    ProcessIsolationManager isolationManager_;
};

} // namespace uce
