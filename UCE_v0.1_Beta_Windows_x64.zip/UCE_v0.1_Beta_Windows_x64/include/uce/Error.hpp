#pragma once
#include <string>
#include <map>
#include <optional>

namespace uce {

enum class ErrorCategory {
    Parser,
    Security,
    Runtime,
    Plugin,
    Backend,
    System
};

enum class ErrorCode {
    // Parser errors
    InvalidSyntax = 1000,
    UnclosedQuote,
    UnclosedBlock,
    InvalidToken,
    MissingArgument,

    // Security errors
    PermissionDenied = 2000,
    UnsafeCommand,
    TimeoutExceeded,
    DepthLimitExceeded,

    // Runtime errors
    CommandNotFound = 3000,
    InvalidArgument,
    ExecutionFailed,
    ResourceLimit,

    // Plugin errors
    InvalidManifest = 4000,
    PluginLoadFailed,
    PluginExecutionFailed,

    // Backend errors
    BackendNotAvailable = 5000,
    ScriptExecutionFailed,
    LanguageNotSupported,

    // System errors
    InternalError = 6000,
    MemoryError,
    ThreadError
};

struct ErrorLocation {
    int line = 0;
    int column = 0;
    std::string source;
};

struct Error {
    ErrorCode code = ErrorCode::InternalError;
    ErrorCategory category = ErrorCategory::System;
    std::string message;
    std::optional<ErrorLocation> location;
    std::map<std::string, std::string> context;

    Error() = default;

    Error(ErrorCode c, ErrorCategory cat, std::string msg,
          std::optional<ErrorLocation> loc = std::nullopt,
          std::map<std::string, std::string> ctx = {})
        : code(c), category(cat), message(std::move(msg)),
          location(std::move(loc)), context(std::move(ctx)) {}

    std::string toString() const;
};

} // namespace uce