#pragma once
#include <string>
#include <vector>
#include <set>
#include <chrono>
#include <memory>
#include <functional>

namespace uce {

struct ScriptExecutionContext;

// File permission types
enum class FilePermission {
    READ,
    WRITE,
    APPEND,
    DELETE_FILE,
    READ_WRITE,
    LIST_DIRECTORIES
};

// Network permission types
enum class NetworkPermission {
    HTTP_GET,
    HTTP_POST,
    HTTP_PUT,
    DNS_RESOLVE,
    SOCKET_LISTEN
};

// Process permission types
enum class ProcessPermission {
    EXECUTE_SYSTEM,
    SPAWN_SUBPROCESS,
    ENVIRONMENT_READ,
    ENVIRONMENT_WRITE
};

// Resource limits
struct SandboxLimits {
    size_t maxMemoryMB = 512;              // Max memory usage
    size_t maxFileSize = 100 * 1024 * 1024; // Max file size (100MB)
    size_t maxOpenFiles = 10;              // Max concurrent open files
    uint32_t maxCPUPercent = 90;           // Max CPU usage
    size_t maxNetworkBandwidth = 10 * 1024 * 1024; // Max bandwidth (10MB)

    std::chrono::milliseconds timeout{5000}; // Execution timeout
};

// File access sandbox
class FileSandbox {
public:
    // Allow reading from specific paths (supports glob patterns)
    void allowReadPath(const std::string& pattern);

    // Allow writing to specific paths (supports glob patterns)
    void allowWritePath(const std::string& pattern);

    // Block specific paths (supports glob patterns)
    void blockPath(const std::string& pattern);

    // Check if access is allowed
    bool isReadAllowed(const std::string& path) const;
    bool isWriteAllowed(const std::string& path) const;
    bool isAppendAllowed(const std::string& path) const;
    bool isDeleteAllowed(const std::string& path) const;
    bool isListDirsAllowed(const std::string& path) const;

    // Access required for sandbox IPC serialization
    const std::vector<std::string>& allowedReadPaths() const { return allowedReadPaths_; }
    const std::vector<std::string>& allowedWritePaths() const { return allowedWritePaths_; }
    const std::vector<std::string>& blockedPaths() const { return blockedPaths_; }

private:
    std::vector<std::string> allowedReadPaths_;
    std::vector<std::string> allowedWritePaths_;
    std::vector<std::string> blockedPaths_;

    bool matchesPattern(const std::string& path, const std::string& pattern) const;
};

// Network access sandbox
class NetworkSandbox {
public:
    // Allow specific hosts/domains (supports wildcards)
    void allowHost(const std::string& pattern);

    // Block specific hosts/domains (supports wildcards)
    void blockHost(const std::string& pattern);

    // Set port restrictions
    void setPortRange(uint16_t min, uint16_t max);

    // Check if network access is allowed
    bool isAccessAllowed(const std::string& host, uint16_t port) const;

private:
    std::vector<std::string> allowedHosts_;
    std::vector<std::string> blockedHosts_;
    uint16_t minPort_ = 0;
    uint16_t maxPort_ = 65535;

    bool matchesHostPattern(const std::string& host, const std::string& pattern) const;
};

// Module restrictions
class ModuleSandbox {
public:
    // Whitelist allowed modules
    void allowModule(const std::string& moduleName);

    // Blacklist forbidden modules
    void blockModule(const std::string& moduleName);

    // Check if module is allowed
    bool isModuleAllowed(const std::string& moduleName) const;

    // Access required for sandbox IPC serialization
    std::vector<std::string> allowedModules() const;
    std::vector<std::string> blockedModules() const;

    // Set default allow policy
    void setDefaultAllow(bool allow) { defaultAllow_ = allow; }

    // Get pre-configured safe environments
    static ModuleSandbox pythonSafe();
    static ModuleSandbox luaSafe();
    static ModuleSandbox pythonRelaxed();
    static ModuleSandbox luaRelaxed();

private:
    std::set<std::string> allowedModules_;
    std::set<std::string> blockedModules_;
    bool defaultAllow_ = false; // If true, allow by default except blocked
};

// Process execution sandbox
class ProcessSandbox {
public:
    // Allow specific commands (supports wildcards)
    void allowCommand(const std::string& pattern);

    // Block specific commands (supports wildcards)
    void blockCommand(const std::string& pattern);

    // Check if execution is allowed
    bool isCommandAllowed(const std::string& command) const;

private:
    std::vector<std::string> allowedCommands_;
    std::vector<std::string> blockedCommands_;

    bool matchesCommandPattern(const std::string& command, const std::string& pattern) const;
};

// Resource monitoring
class SandboxResourceMonitor {
public:
    void start();
    void stop();
    void reset();

    // Current resource usage
    struct ResourceUsage {
        size_t memoryMB = 0;
        size_t openFiles = 0;
        uint32_t cpuPercent = 0;
        size_t networkBytes = 0;
        std::chrono::milliseconds elapsedTime{0};
    };

    ResourceUsage currentUsage() const;

    // Check if resource limits exceeded
    bool isLimitExceeded(const SandboxLimits& limits) const;

private:
    std::chrono::steady_clock::time_point startTime_;
    bool monitoring_ = false;
    ResourceUsage usage_;
};

// Main execution sandbox
class ExecutionSandbox {
public:
    // Create a sandbox with specific configuration
    explicit ExecutionSandbox(const std::string& profile = "default");

    // Set file permissions
    void files(FileSandbox sandbox) { fileSandbox_ = std::move(sandbox); }

    // Set network permissions
    void network(NetworkSandbox sandbox) { networkSandbox_ = std::move(sandbox); }

    // Set module restrictions
    void modules(ModuleSandbox sandbox) { moduleSandbox_ = std::move(sandbox); }

    // Set process permissions
    void processes(ProcessSandbox sandbox) { processSandbox_ = std::move(sandbox); }

    // Convenience helpers
    void setFileAccessPattern(const std::string& pattern, FilePermission permission) {
        if (permission == FilePermission::READ || permission == FilePermission::READ_WRITE) {
            fileSandbox_.allowReadPath(pattern);
        }
        if (permission == FilePermission::WRITE || permission == FilePermission::READ_WRITE || permission == FilePermission::APPEND || permission == FilePermission::DELETE_FILE) {
            fileSandbox_.allowWritePath(pattern);
        }
    }

    void blockFilePath(const std::string& pattern) { fileSandbox_.blockPath(pattern); }

    void allowModule(const std::string& moduleName) { moduleSandbox_.allowModule(moduleName); }
    void blockModule(const std::string& moduleName) { moduleSandbox_.blockModule(moduleName); }

    // Expose sandbox details for IPC transfer
    std::vector<std::string> fileReadAllowPatterns() const { return fileSandbox_.allowedReadPaths(); }
    std::vector<std::string> fileWriteAllowPatterns() const { return fileSandbox_.allowedWritePaths(); }
    std::vector<std::string> blockedFilePaths() const { return fileSandbox_.blockedPaths(); }
    std::vector<std::string> allowedModuleNames() const { return moduleSandbox_.allowedModules(); }
    std::vector<std::string> blockedModuleNames() const { return moduleSandbox_.blockedModules(); }

    // Set resource limits
    void limits(const SandboxLimits& limits) { limits_ = limits; }

    // Apply sandbox to context
    void applyTo(ScriptExecutionContext& context);

    // Get sandbox components (for backends to use)
    const FileSandbox& fileSandbox() const { return fileSandbox_; }
    const NetworkSandbox& networkSandbox() const { return networkSandbox_; }
    const ModuleSandbox& moduleSandbox() const { return moduleSandbox_; }
    const ProcessSandbox& processSandbox() const { return processSandbox_; }
    const SandboxLimits& limits() const { return limits_; }

    // Pre-configured profiles
    static ExecutionSandbox restricted();   // Very restrictive
    static ExecutionSandbox standard();     // Balanced (default)
    static ExecutionSandbox relaxed();      // Permissive
    static ExecutionSandbox unrestricted(); // No restrictions

    // Resource monitoring
    void startResourceMonitoring();
    void stopResourceMonitoring();
    SandboxResourceMonitor::ResourceUsage currentResourceUsage() const;
    bool isResourceLimitExceeded() const;

private:
    FileSandbox fileSandbox_;
    NetworkSandbox networkSandbox_;
    ModuleSandbox moduleSandbox_;
    ProcessSandbox processSandbox_;
    SandboxLimits limits_;
    std::shared_ptr<SandboxResourceMonitor> resourceMonitor_;

    void setupDefaultProfile(const std::string& profile);
};

} // namespace uce