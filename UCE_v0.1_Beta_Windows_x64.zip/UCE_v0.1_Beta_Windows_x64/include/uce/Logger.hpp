#pragma once
#include <functional>
#include <string>
#include <chrono>

namespace uce {

enum class LogLevel {
    Trace,
    Debug,
    Info,
    Warn,
    Error,
    Fatal,
};

class ILogger {
public:
    virtual ~ILogger() = default;
    virtual void log(LogLevel level, const std::string& message) = 0;
    virtual void setLevel(LogLevel level) = 0;
};

class ConsoleLogger : public ILogger {
public:
    using LogSink = std::function<void(LogLevel, const std::string&)>;

    explicit ConsoleLogger(LogSink sink = nullptr);
    void log(LogLevel level, const std::string& message) override;
    void setLevel(LogLevel level) { minLevel_ = level; }

    // Safety features
    void setEnabled(bool enabled) { enabled_ = enabled; }
    bool isEnabled() const { return enabled_; }

private:
    std::string formatMessage(LogLevel level, const std::string& message) const;

    LogSink sink_;
    LogLevel minLevel_ = LogLevel::Info;
    bool enabled_ = true;
};

} // namespace uce
