#pragma once
#include "uce/Command.hpp"
#include "uce/Error.hpp"
#include <stdexcept>
#include <string>
#include <vector>
#include <memory>
#include <optional>

namespace uce {

enum class TokenType {
    Identifier,
    String,
    Number,
    Colon,
    Equals,
    LBrace,
    RBrace,
    LParen,
    RParen,
    Comma,
    EndOfFile
};

struct Token {
    TokenType type;
    std::string value;
    int line;
    int column;
};

struct ParserLimits {
    size_t maxTokens = 100;
    size_t maxStringLength = 1024;
    int maxNestingDepth = 5;
};

class Parser {
public:
    explicit Parser(ParserLimits limits = {});

    CommandRequest parse(const std::string& source) const;

    // Strict validation mode
    void setStrictMode(bool strict) { strictMode_ = strict; }
    bool isStrictMode() const { return strictMode_; }

private:
    std::vector<Token> tokenize(const std::string& source) const;
    CommandRequest parseTokens(const std::vector<Token>& tokens) const;

    // Safety checks
    CommandResult validateTokenLimits(const std::vector<Token>& tokens) const;
    CommandResult validateSyntax(const std::vector<Token>& tokens) const;

    ParserLimits limits_;
    bool strictMode_ = true;
};

} // namespace uce
