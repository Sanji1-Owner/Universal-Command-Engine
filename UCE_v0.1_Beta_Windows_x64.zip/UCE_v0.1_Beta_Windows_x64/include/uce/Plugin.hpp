#pragma once
#include <string>
#include <vector>
#include <memory>
#include <map>

namespace uce {

struct PluginManifest {
    std::string id;
    std::string name;
    std::string version;
    std::string author;
    std::string description;
    std::vector<std::string> permissions;
    std::string entry;
    std::vector<std::string> commands;
};

class IPlugin {
public:
    virtual ~IPlugin() = default;
    virtual void onLoad() = 0;
    virtual void onEnable() = 0;
    virtual void onDisable() = 0;
    virtual void onUnload() = 0;
    virtual const PluginManifest& manifest() const = 0;
};

class PluginManager {
public:
    void loadPlugin(const std::string& manifestPath);
    void unloadPlugin(const std::string& id);
    std::vector<std::string> listPlugins() const;

private:
    std::map<std::string, std::shared_ptr<IPlugin>> plugins_;
};

} // namespace uce
