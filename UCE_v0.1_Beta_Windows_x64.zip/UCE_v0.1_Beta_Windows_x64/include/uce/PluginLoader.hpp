#pragma once

#include "uce/ScriptBackend.hpp"
#include <string>
#include <memory>
#include <map>
#include <vector>
#include <functional>

namespace uce {

/**
 * @brief Plugin metadata
 */
struct PluginInfo {
    std::string name;           // Plugin name
    std::string version;        // Plugin version
    std::string description;    // Plugin description
    std::string author;         // Plugin author
    int apiVersion;             // UCE API version required
    std::string filePath;       // Path to plugin file (.dll, .so, etc)
    bool loaded;                // Whether plugin is loaded
    std::string loadError;      // Error message if load failed
};

/**
 * @brief Function signature for plugin factory function
 * 
 * Plugin must export: IScriptBackend* createBackend()
 * And: void destroyBackend(IScriptBackend* backend)
 */
using BackendFactory = std::function<IScriptBackend*()>;
using BackendDestructor = std::function<void(IScriptBackend*)>;

/**
 * @brief Dynamic plugin loader for script backends
 * 
 * Supports loading backends from shared libraries (.dll on Windows, .so on Linux)
 * 
 * Usage:
 *   PluginLoader loader;
 *   if (loader.loadPlugin("path/to/backend.dll")) {
 *       auto backend = loader.createBackend("my_backend");
 *   }
 */
class PluginLoader {
public:
    /**
     * @brief Load a plugin from a file
     * @param filePath Path to the plugin file (.dll, .so, etc)
     * @param backendName Name to register the backend as
     * @return true if loaded successfully
     */
    bool loadPlugin(const std::string& filePath, const std::string& backendName);

    /**
     * @brief Unload a previously loaded plugin
     * @param backendName Name of the backend to unload
     * @return true if unloaded successfully
     */
    bool unloadPlugin(const std::string& backendName);

    /**
     * @brief Create a backend instance from a loaded plugin
     * @param backendName Name of the registered backend
     * @return Backend instance, or nullptr if not found
     */
    std::unique_ptr<IScriptBackend> createBackend(const std::string& backendName);

    /**
     * @brief Check if a backend is loaded
     * @param backendName Name of the backend
     * @return true if backend is loaded and available
     */
    bool isLoaded(const std::string& backendName) const;

    /**
     * @brief Get information about a loaded plugin
     * @param backendName Name of the backend
     * @return Plugin information, or empty if not found
     */
    PluginInfo getPluginInfo(const std::string& backendName) const;

    /**
     * @brief Get list of all loaded plugins
     * @return Vector of loaded plugin names
     */
    std::vector<std::string> loadedPlugins() const;

    /**
     * @brief Get detailed information about all loaded plugins
     * @return Map of plugin name to PluginInfo
     */
    std::map<std::string, PluginInfo> allPluginsInfo() const;

    /**
     * @brief Unload all plugins
     */
    void unloadAll();

    /**
     * @brief Get the last error message
     */
    const std::string& lastError() const { return lastError_; }

private:
    struct PluginHandle {
        void* handle;                           // Platform-specific handle
        BackendFactory factory;                 // Factory function
        BackendDestructor destructor;           // Destructor function
        PluginInfo info;
    };

    std::map<std::string, PluginHandle> loadedPlugins_;
    mutable std::string lastError_;

    /**
     * @brief Load symbol from plugin
     */
    void* loadSymbol(void* handle, const char* symbolName);

    /**
     * @brief Unload platform-specific handle
     */
    void unloadHandle(void* handle);

    /**
     * @brief Get platform-specific error message
     */
    std::string getPlatformError();
};

/**
 * @brief Built-in backends registry
 * 
 * Manages statically compiled backends (Python, Lua, Native, JavaScript)
 * These don't require plugin loading but use the same interface
 */
class BuiltinBackendRegistry {
public:
    /**
     * @brief Register a built-in backend
     */
    static void registerBackend(const std::string& name, BackendFactory factory);

    /**
     * @brief Create a built-in backend
     */
    static std::unique_ptr<IScriptBackend> createBackend(const std::string& name);

    /**
     * @brief Check if a built-in backend exists
     */
    static bool exists(const std::string& name);

    /**
     * @brief Get list of all registered backends
     */
    static std::vector<std::string> registeredBackends();

private:
    static std::map<std::string, BackendFactory> backends_;
};

} // namespace uce
