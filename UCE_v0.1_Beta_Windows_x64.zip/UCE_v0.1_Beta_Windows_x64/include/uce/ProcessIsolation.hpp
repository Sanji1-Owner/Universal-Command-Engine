#pragma once
#include <windows.h>
#include <string>
#include <vector>
#include <memory>
#include <chrono>
#include <map>
#include <functional>
#include <future>
#include <thread>
#include <mutex>
#include <condition_variable>
#include "uce/CommandResult.hpp"

namespace uce {

// Forward declarations
class ExecutionSandbox;
struct ScriptExecutionContext;

// IPC Message types for communication between main process and script runner
enum class IPCMessageType {
    ExecuteScript,
    ScriptResult,
    ScriptError,
    Heartbeat,
    Terminate,
    MemoryUsage,
    FileAccess,
    NetworkAccess
};

struct IPCMessage {
    IPCMessageType type;
    std::string payload;
    std::map<std::string, std::string> metadata;

    std::string serialize() const;
    static IPCMessage deserialize(const std::string& data);
};

// Process isolation manager
class ProcessIsolationManager {
public:
    ProcessIsolationManager();
    ~ProcessIsolationManager();

    // Initialize the isolation system
    bool initialize();

    // Execute script in isolated process
    std::shared_future<CommandResult> executeIsolated(
        const std::string& language,
        ScriptExecutionContext& context
    );

    // Check if isolation is available
    bool isAvailable() const { return initialized_; }

    // Get isolation statistics
    struct IsolationStats {
        size_t activeProcesses = 0;
        size_t totalExecutions = 0;
        size_t crashedProcesses = 0;
        size_t timeoutKills = 0;
    };
    IsolationStats getStats() const;

private:
    bool initialized_ = false;
    mutable std::mutex mutex_;
    std::mutex ipcMutex_;
    IsolationStats stats_;

    // Process management
    struct IsolatedProcess {
        int processId = 0;
        std::thread monitorThread;
        std::shared_future<CommandResult> resultFuture;
        std::chrono::steady_clock::time_point startTime;
        bool terminated = false;
    };

    std::vector<std::unique_ptr<IsolatedProcess>> activeProcesses_;

    // IPC communication
    bool sendIPCMessage(int processId, const IPCMessage& message);
    IPCMessage receiveIPCMessage(int processId, std::chrono::milliseconds timeout);

    // Process lifecycle helpers
    std::string getScriptRunnerPath() const;
    void terminateAllProcesses();
    void cleanupProcessHandles(int processId);

#ifdef _WIN32
    std::string readFromPipe(HANDLE hPipe);
#endif

    // Process lifecycle
    int spawnScriptRunner(const std::string& language, const ScriptExecutionContext& context);
    void terminateProcess(int processId);
    void cleanupCompletedProcesses();

#ifdef _WIN32
    std::map<int, void*> writeHandles_;
    std::map<int, void*> readHandles_;
#endif
};

// Script runner process (separate executable)
class ScriptRunnerProcess {
public:
    ScriptRunnerProcess(int parentPid, const std::string& language);
    ~ScriptRunnerProcess();

    // Main execution loop for the isolated process
    int run();

    // Execute script in this isolated process
    CommandResult executeScript(const std::string& scriptSource,
                               const ScriptExecutionContext& context);

private:
    int parentPid_;
    std::string language_;
    std::shared_ptr<ExecutionSandbox> sandbox_;
#ifdef _WIN32
    HANDLE memoryJobObject_ = nullptr;
#endif
    std::atomic<bool> memoryMonitorActive_{false};
    std::thread memoryMonitorThread_;

    // IPC communication
    bool sendMessage(const IPCMessage& message);
    IPCMessage receiveMessage(std::chrono::milliseconds timeout = std::chrono::milliseconds(1000));

    // Resource monitoring
    void monitorResources();
    size_t getCurrentMemoryUsage();
    void enforceMemoryLimits(size_t maxMemory);

    // Security enforcement
    void setupSandbox(const ScriptExecutionContext& context);
    void enforceNetworkRestrictions();
    void enforceFileSystemRestrictions(const std::string& sandboxRoot);

    // Signal handling
    void setupSignalHandlers();
    static void signalHandler(int signal);
};

// Virtual file system for isolated execution
class VirtualFileSystem {
public:
    VirtualFileSystem(const std::string& rootPath);
    ~VirtualFileSystem();

    // File operations within virtual root
    bool isPathAllowed(const std::string& path) const;
    std::string resolveVirtualPath(const std::string& virtualPath) const;
    std::vector<std::string> listAllowedPaths() const;

    // Sandbox root management
    void setSandboxRoot(const std::string& root);
    std::string getSandboxRoot() const { return sandboxRoot_; }

private:
    std::string sandboxRoot_;
    std::vector<std::string> allowedPaths_;
    std::vector<std::string> blockedPatterns_;

    bool matchesBlockedPattern(const std::string& path) const;
};

// Network access controller for isolated processes
class NetworkAccessController {
public:
    NetworkAccessController();
    ~NetworkAccessController();

    // Network policy enforcement
    bool isHostAllowed(const std::string& host) const;
    bool isPortAllowed(int port) const;
    void addAllowedHost(const std::string& host);
    void addAllowedPort(int port);

    // Network interception (platform-specific)
    void enableNetworkInterception();
    void disableNetworkInterception();

private:
    std::vector<std::string> allowedHosts_;
    std::vector<int> allowedPorts_;
    bool interceptionEnabled_ = false;

    // Platform-specific network blocking
    void blockSocketsOnWindows();
    void blockSocketsOnUnix();
};

// Memory monitor for isolated processes
class ProcessMemoryMonitor {
public:
    ProcessMemoryMonitor(size_t maxMemoryBytes);
    ~ProcessMemoryMonitor();

    // Memory tracking
    size_t getCurrentUsage() const;
    bool isLimitExceeded() const;
    void enforceLimit();

    // Memory statistics
    struct MemoryStats {
        size_t currentUsage = 0;
        size_t peakUsage = 0;
        size_t limit = 0;
    };
    MemoryStats getStats() const;

private:
    size_t maxMemory_;
    MemoryStats stats_;

    size_t queryMemoryUsage() const;
};

} // namespace uce