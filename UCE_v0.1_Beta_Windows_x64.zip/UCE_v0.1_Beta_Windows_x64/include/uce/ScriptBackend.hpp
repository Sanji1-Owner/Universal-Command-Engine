#pragma once
#include "uce/CommandResult.hpp"
#include "uce/ScriptExecution.hpp"
#include <string>
#include <memory>

namespace uce {

class EngineContext;

class IScriptBackend {
public:
    virtual ~IScriptBackend() = default;
    virtual CommandResult execute(const std::string& source, EngineContext& context) = 0;
    virtual CommandResult executeInContext(ScriptExecutionContext& execCtx) = 0;
    virtual std::string language() const = 0;
    virtual bool isAvailable() const = 0;
};

class NativeBackend : public IScriptBackend {
public:
    CommandResult execute(const std::string& source, EngineContext& context) override;
    CommandResult executeInContext(ScriptExecutionContext& execCtx) override;
    std::string language() const override { return "native"; }
    bool isAvailable() const override { return true; }
};

#ifdef UCE_ENABLE_PYTHON
class PythonBackend : public IScriptBackend {
public:
    PythonBackend();
    ~PythonBackend();

    CommandResult execute(const std::string& source, EngineContext& context) override;
    CommandResult executeInContext(ScriptExecutionContext& execCtx) override;
    std::string language() const override { return "python"; }
    bool isAvailable() const override;

private:
    bool initialized_ = false;
    class PythonImpl;
    std::unique_ptr<PythonImpl> impl_;
};
#endif

#ifdef UCE_ENABLE_LUA
class LuaBackend : public IScriptBackend {
public:
    LuaBackend();
    ~LuaBackend();

    CommandResult execute(const std::string& source, EngineContext& context) override;
    CommandResult executeInContext(ScriptExecutionContext& execCtx) override;
    std::string language() const override { return "lua"; }
    bool isAvailable() const override;

private:
    class LuaImpl;
    std::unique_ptr<LuaImpl> impl_;
};
#endif

#ifdef UCE_ENABLE_JS
class JavaScriptBackend : public IScriptBackend {
public:
    CommandResult execute(const std::string& source, EngineContext& context) override;
    CommandResult executeInContext(ScriptExecutionContext& execCtx) override;
    std::string language() const override { return "javascript"; }
    bool isAvailable() const override { return false; } // Not implemented yet
};
#endif

} // namespace uce
