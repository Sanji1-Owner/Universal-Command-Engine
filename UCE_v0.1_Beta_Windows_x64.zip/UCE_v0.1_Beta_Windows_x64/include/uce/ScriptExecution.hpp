#pragma once
#include <string>
#include <map>
#include <memory>
#include <chrono>
#include <functional>
#include "uce/CommandResult.hpp"

namespace uce {

class Engine;
class ExecutionSandbox;

// Isolated execution context for scripts
struct ScriptExecutionContext {
    std::string scriptSource;
    std::chrono::milliseconds timeout{5000}; // 5 seconds default
    std::map<std::string, std::string> environment;
    std::map<std::string, std::string> boundCommands;
    bool sandboxed = true;
    size_t maxMemoryMB = 0; // 0 means use sandbox/default limits

    // Output capture
    std::string stdoutCapture;
    std::string stderrCapture;

    // Engine binding for command execution
    Engine* engine = nullptr;

    // Sandbox configuration (optional)
    std::shared_ptr<ExecutionSandbox> sandbox;

    // Timeout handling
    std::chrono::steady_clock::time_point startTime;
    bool isTimedOut() const;
};

// Command binding interface for scripts
class IScriptCommandBinder {
public:
    virtual ~IScriptCommandBinder() = default;
    virtual void bindCommand(const std::string& scriptName, const std::string& engineCommand) = 0;
    virtual CommandResult executeBoundCommand(const std::string& scriptName, const std::vector<std::string>& args) = 0;
};

inline bool ScriptExecutionContext::isTimedOut() const {
    auto now = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - startTime);
    return elapsed > timeout;
}

} // namespace uce