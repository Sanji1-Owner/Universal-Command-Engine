#pragma once
#include "uce/CommandResult.hpp"
#include "uce/Error.hpp"
#include <string>
#include <set>
#include <chrono>

namespace uce {

enum class Permission {
    UiCreate,
    UiModify,
    FileRead,
    FileWrite,
    ProcessExecute,
    ScriptPython,
    ScriptLua,
    ScriptJavaScript,
    NetworkAccess,
    SandboxOverride,  // Allow bypassing sandbox restrictions
};

struct SecurityLimits {
    std::chrono::milliseconds executionTimeout{5000}; // 5 seconds default
    size_t maxCommandLength{1024}; // 1KB max command
    size_t maxTokens{100}; // Max parsed tokens
    int maxExecutionDepth{10}; // Prevent recursion abuse
};

class SecurityPolicy {
public:
    SecurityPolicy();

    // Permission management
    void allow(Permission permission);
    void deny(Permission permission);
    bool isAllowed(Permission permission) const;

    // Strict validation
    CommandResult require(Permission permission, const std::string& feature) const;
    CommandResult validateCommandLength(const std::string& command) const;
    CommandResult validateTokenCount(size_t tokenCount) const;
    CommandResult checkExecutionDepth(int currentDepth) const;

    // Limits management
    void setLimits(const SecurityLimits& limits);
    const SecurityLimits& limits() const { return limits_; }

    // Security violation tracking
    void recordViolation(const std::string& violation) const;
    size_t violationCount() const { return violations_; }

    // Sandbox integration
    bool canOverrideSandbox() const { return isAllowed(Permission::SandboxOverride); }

private:
    std::set<Permission> allowed_;
    SecurityLimits limits_;
    mutable size_t violations_ = 0;
};

} // namespace uce
