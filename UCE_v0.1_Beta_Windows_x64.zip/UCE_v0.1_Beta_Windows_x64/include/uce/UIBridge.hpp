#pragma once
#include <string>
#include <map>
#include <vector>
#include <memory>

namespace uce {

struct UIAction {
    std::string id;
    std::string type;
    std::string title;
    std::string icon;
    std::string action;
    std::map<std::string, std::string> metadata;
};

class IUIBridge {
public:
    virtual ~IUIBridge() = default;
    virtual void submit(const UIAction& action) = 0;
};

class ConsoleUIBridge : public IUIBridge {
public:
    void submit(const UIAction& action) override;
    const std::vector<UIAction>& actions() const { return actions_; }
    void clear();

private:
    std::vector<UIAction> actions_;
};

} // namespace uce
