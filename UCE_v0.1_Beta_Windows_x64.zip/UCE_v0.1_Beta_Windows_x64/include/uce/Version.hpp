#pragma once

#include <string>

/**
 * UCE - Universal Command Engine
 * Version Information
 * 
 * v1.0.0 - Production Release (May 2, 2026)
 */

namespace uce {

/**
 * @brief Version information for UCE library
 */
struct Version {
    static constexpr int MAJOR = 1;
    static constexpr int MINOR = 0;
    static constexpr int PATCH = 0;
    static constexpr const char* BUILD_DATE = __DATE__;
    static constexpr const char* BUILD_TIME = __TIME__;
    
    /**
     * @brief Get version string
     * @return Version in format "major.minor.patch"
     */
    static std::string toString() {
        return std::to_string(MAJOR) + "." + 
               std::to_string(MINOR) + "." + 
               std::to_string(PATCH);
    }
    
    /**
     * @brief Get full version info
     * @return Version string with build information
     */
    static std::string getFullInfo() {
        return "UCE v" + toString() + 
               " (Built: " + std::string(BUILD_DATE) + 
               " " + std::string(BUILD_TIME) + ")";
    }
};

} // namespace uce

#define UCE_VERSION_MAJOR 1
#define UCE_VERSION_MINOR 0
#define UCE_VERSION_PATCH 0
#define UCE_VERSION "1.0.0"
#define UCE_VERSION_STR "UCE/1.0.0"